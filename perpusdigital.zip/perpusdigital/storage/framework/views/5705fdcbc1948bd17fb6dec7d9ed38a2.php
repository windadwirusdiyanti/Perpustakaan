

<h1>Tambah Buku</h1>

<?php if($errors->any()): ?>
    <div>
        <strong>Error:</strong>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<form action="<?php echo e(route('bukus.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>

    <label for="judul">Judul:</label>
    <input type="text" name="judul" required>
    <br>

    <label for="penulis">Penulis:</label>
    <input type="text" name="penulis" required>
    <br>

    <label for="penerbit">Penerbit:</label>
    <input type="text" name="penerbit" required>
    <br>

    <label for="tahun_terbit">Tahun Terbit:</label>
    <input type="number" name="tahun_terbit" required>
    <br>

    <button type="submit">Simpan</button>
</form>
<?php /**PATH C:\perpusdigital\perpusdigital\resources\views/bukus/create.blade.php ENDPATH**/ ?>